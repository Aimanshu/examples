@extends('admin.layouts.app')

@section('content')
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Offer List
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Offer List</li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">
      <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>#</th>
                <th>Offer Name</th>
                <th>Offer Description</th>
                <th>Offer Url</th>
                <th>Offer Image Url</th>
                <th>Created Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        @foreach($offers as $key => $offer)
            @php $key++;@endphp
            <tr>
                <td>{{$key}}</td>
                <td>{!! str_limit(strip_tags($offer->offer_name),25) !!}</td>
                <td>{!! str_limit(strip_tags($offer->offer_description),25) !!}</td>
                <td>{!! str_limit(strip_tags($offer->offer_url),20) !!}</td>
                <td>{!! str_limit(strip_tags($offer->offer_image_url),20) !!}</td>
                <td>{{date('d-M-Y',strtotime($offer->created_at))}}</td>
                <td>
                    @if($offer->is_active ==0)
                        <button type="button" class="btn btn-primary" onclick='updateStatus("offer",1,{{$offer->offer_id}})'>Active</button>
                        <button type="button" class="btn btn-danger" style="cursor: not-allowed">Deactived</button>  
                    @elseif($offer->is_active ==1)
                        <button type="button" class="btn btn-success" style="cursor: not-allowed">Actived</button>
                        <button type="button" class="btn btn-warning" onclick='updateStatus("offer",0,{{$offer->offer_id}})'>Deactive</button>      
                    @else
                        <button type="button" class="btn btn-primary" onclick='updateStatus("offer",1,{{$offer->offer_id}})'>Active</button>  
                        <button type="button" class="btn btn-warning" onclick='updateStatus("offer",0,{{$offer->offer_id}})'>Deactive</button>      
                    @endif
                </td>
            </tr>
            @endforeach 
        </tbody>
        <tfoot>
            <tr>
                <th>#</th>
                <th>Offer Name</th>
                <th>Offer Description</th>
                <th>Offer Url</th>
                <th>Offer Image Url</th>
                <th>Created Date</th>
                <th>Status</th>
            </tr>
        </tfoot>
    </table>
    </section>    
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@endsection

@section('script')
<script>
$(document).ready(function() {
    $('#example').DataTable();
} );

</script>
@endsection		
