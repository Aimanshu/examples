@extends('admin.layouts.app')

@section('content')
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Pfd List
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Pdf List</li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">
      <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>#</th>
                <th>Pfd Name</th>
                <th>Pfd Description</th>
                <th>Pfd Url</th>
                <th>Pfd Image Url</th>
                <th>Created Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        @foreach($PfdFiles as $key => $PfdFile)
            @php $key++;@endphp
            <tr>
                <td>{{$key}}</td>
                <td>{!! str_limit(strip_tags($PfdFile->pfd_name),25) !!}</td>
                <td>{!! str_limit(strip_tags($PfdFile->pfd_description),25) !!}</td>
                <td>{!! str_limit(strip_tags($PfdFile->pfd_url),20) !!}</td>
                <td>{!! str_limit(strip_tags($PfdFile->pfd_image_url),20) !!}</td>
                <td>{{date('d-M-Y',strtotime($PfdFile->created_at))}}</td>
                <td>
                    @if($PfdFile->is_active ==0)
                        <button type="button" class="btn btn-primary" onclick='updateStatus("PfdFile",1,{{$PfdFile->pfd_id}})'>Active</button>
                        <button type="button" class="btn btn-danger" style="cursor: not-allowed">Deactived</button>  
                    @elseif($PfdFile->is_active ==1)
                        <button type="button" class="btn btn-success" style="cursor: not-allowed">Actived</button>
                        <button type="button" class="btn btn-warning" onclick='updateStatus("PfdFile",0,{{$PfdFile->pfd_id}})'>Deactive</button>      
                    @else
                        <button type="button" class="btn btn-primary" onclick='updateStatus("PfdFile",1,{{$PfdFile->pfd_id}})'>Active</button>  
                        <button type="button" class="btn btn-warning" onclick='updateStatus("PfdFile",0,{{$PfdFile->pfd_id}})'>Deactive</button>      
                    @endif
                </td>
            </tr>
            @endforeach 
        </tbody>
        <tfoot>
            <tr>
                <th>#</th>
                <th>Offer Name</th>
                <th>Offer Description</th>
                <th>Offer Url</th>
                <th>Offer Image Url</th>
                <th>Created Date</th>
                <th>Status</th>
            </tr>
        </tfoot>
    </table>
    </section>    
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@endsection

@section('script')
<script>
$(document).ready(function() {
    $('#example').DataTable();
} );

</script>
@endsection		
