@extends('admin.layouts.app')

@section('content')
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Blog List
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Blog List</li>
      </ol>
    </section>

    <!-- Main content -->
     <section class="content">
      <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>#</th>
                <th>Blog Name</th>
                <th>Long Description</th>
                <th>Url</th>
                <th>Blog Image</th>
                <th>Created Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        @foreach($blogs as $key => $blog)
            @php $key++;@endphp
            <tr>
                <td>{{$key}}</td>
                <td>{!! str_limit(strip_tags($blog->blog_name),20) !!}</td>
                <td>{!! str_limit(strip_tags($blog->blog_description),45) !!}</td>
                <td>{!! str_limit(strip_tags($blog->blog_url),15) !!}</td>
                <td>{!! str_limit(strip_tags($blog->blog_image_url),15) !!}</td>
                <td>{{date('d-M-Y',strtotime($blog->created_at))}}</td>
                <td>
                    @if($blog->is_active ==0)
                        <button type="button" class="btn btn-primary" onclick='updateStatus("blog",1,{{$blog->blog_id}})'>Active</button>
                        <button type="button" class="btn btn-danger" style="cursor: not-allowed">Deactived</button>  
                    @elseif($blog->is_active ==1)
                        <button type="button" class="btn btn-success" style="cursor: not-allowed">Actived</button>
                        <button type="button" class="btn btn-warning" onclick='updateStatus("blog",0,{{$blog->blog_id}})'>Deactive</button>      
                    @else
                        <button type="button" class="btn btn-primary" onclick='updateStatus("blog",1,{{$blog->blog_id}})'>Active</button>  
                        <button type="button" class="btn btn-warning" onclick='updateStatus("blog",0,{{$blog->blog_id}})'>Deactive</button>      
                    @endif
                </td>
            </tr>
            @endforeach 
        </tbody>
        <tfoot>
            <tr>
                <th>#</th>
                <th>Blog Name</th>
                <th>Long Description</th>
                <th>Url</th>
                <th>Blog Image</th>
                <th>Created Date</th>
                <th>Action</th>
            </tr>
        </tfoot>
    </table>



    </section>    
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

@endsection

@section('script')
<script>
$(document).ready(function() {
    $('#example').DataTable();
} );


</script>
@endsection		
